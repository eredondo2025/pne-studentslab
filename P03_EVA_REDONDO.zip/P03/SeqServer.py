import socket
import termcolor
from P01.Seq1 import Seq

ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

PORT = 8080
IP = "127.0.0.1"

SEQUENCES = [
    "ACCTCCTCTCCAGC",
    "CCCTAGCCTGACTC",
    "CAAGGTCCCCTTCT",
    "GATTACAATTACCA",
    "ACTGCTGGACTCTG"
]
gene_list = ["U5.txt", "ADA.txt", "FRAT1.txt", "FXN.txt", "RNU6_269P.txt"]
FOLDER = "../sequences/"

ls = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

ls.bind((IP, PORT))

ls.listen()

print("SEQ Server configured!")

while True:
    print("Waiting for Clients...")

    try:
        (cs, client_ip_port) = ls.accept()

    except KeyboardInterrupt:
        print("\nServer stopped by the user")
        ls.close()
        exit()

    else:
        print("A client has connected to the server!")
        msg_raw = cs.recv(2048)
        msg = msg_raw.decode().strip()

        parts = msg.split()
        if len(parts) > 0:
            command = parts[0]

            if command == "PING":
                termcolor.cprint("PING command!", "green")
                response = "OK!\n"
                print(response.strip())
                cs.send(response.encode())

            elif command == "GET":
                if len(parts) > 1:
                    termcolor.cprint("GET", "green")
                    index = int(parts[1])
                    response = SEQUENCES[index] + "\n"
                    print(response.strip())
                    cs.send(response.encode())
            elif command == "INFO":
                if len(parts) > 1:
                    termcolor.cprint("INFO", "green")
                    sequence = parts[1]
                    total_len = len(sequence)
                    print("New sequence created!")
                    bases = ['A', 'C', 'G', 'T']
                    response = f"Sequence: {sequence}\nTotal length: {total_len}\n"
                    for base in bases:
                        count = sequence.count(base)
                        percentage = round((count / total_len),2) * 100
                        response += f"{base}: {count} ({percentage}%)\n"

                    print(response.strip())
                    cs.send(response.encode())
            elif command == "COMP":
                if len(parts) > 1:
                    termcolor.cprint("COMP", "green")
                    sequence = parts[1]
                    print("New sequence created!")

                    complement_base = {'A': 'T', 'T': 'A', 'C': 'G', 'G': 'C'}
                    list = []
                    for base in sequence:
                        list.append(complement_base.get(base, base))
                    response = "".join(list) + "\n"
                    print(response.strip())
                    cs.send(response.encode())
            elif command == "REV":
                if len(parts) > 1:
                    termcolor.cprint("REV", "green")
                    sequence = parts[1]
                    print("New sequence created!")
                    response = sequence[::-1] + "\n"
                    print(response.strip())
                    cs.send(response.encode())
            elif command == "GENE":
                if len(parts) > 1:
                    termcolor.cprint("GENE", "green")
                    gene_name = parts[1]
                    s = Seq()
                    print("Null seq created!")

                    file = gene_name + ".txt"

                    if file in gene_list:
                        s.read_fasta(FOLDER + file)

                    response = str(s) + "\n"
                    print(response.strip())
                    cs.send(response.encode())
        cs.close()

